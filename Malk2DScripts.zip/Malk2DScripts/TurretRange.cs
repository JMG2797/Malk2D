﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretRange : MonoBehaviour
{
    private TurretControl parentScript;

    void Start()
    {
        
        parentScript = transform.parent.GetComponent<TurretControl>();

    }


    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
          
            parentScript.target = collision.transform;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            
            parentScript.target = null;
        }
    }
}
