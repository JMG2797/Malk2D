﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class BulletControl : MonoBehaviour
{
    public PlayerControl player;
    public AudioSource Explosion;

    public ParticleSystem Impact;
    public ParticleSystem EnemyExplosion;

    public float bulletSpeed;
    private float lifeTimeCounter;
    private float maxTime;

   



    void Start()
    {
        maxTime = 1f;
        lifeTimeCounter = 0;
        Explosion = GetComponent<AudioSource>();
        Impact = GetComponent<ParticleSystem>();
        EnemyExplosion = GetComponent<ParticleSystem>();
    }

    void Update()
    {
        transform.Translate(Vector2.right * bulletSpeed * Time.deltaTime);

        lifeTimeCounter += Time.deltaTime;
        if (lifeTimeCounter > maxTime)
        {
            
            Destroy(gameObject);
            
        }
    }

  

    private void OnTriggerEnter2D(Collider2D ObjCollision)
    {
        if (ObjCollision.transform.tag == "Enemy")
        {
            
            player.playerScore += 10;
            player.SetUI();
            Destroy(gameObject);
            Destroy(ObjCollision.transform.parent.gameObject);
            Instantiate(EnemyExplosion, transform.position, Quaternion.identity);
            Explosion.Play();


        }

        if (ObjCollision.transform.tag == "Enemy2")
        {
           
            player.playerScore += 20;
            player.SetUI();
            Destroy(gameObject);
            Destroy(ObjCollision.transform.parent.gameObject);
            Instantiate(EnemyExplosion, transform.position, Quaternion.identity);
            Explosion.Play();
        }

        if (ObjCollision.transform.tag == "Turret1")
        {
            
            player.playerScore += 3;
            player.SetUI();
            Destroy(gameObject);
            Destroy(ObjCollision.transform.parent.gameObject);
            Instantiate(EnemyExplosion, transform.position, Quaternion.identity);
            Explosion.Play();


        }

        if (ObjCollision.transform.tag == "Turret2")
        {
          
            player.playerScore += 5;
            player.SetUI();
            Destroy(gameObject);
            Destroy(ObjCollision.transform.parent.gameObject);
            Instantiate(EnemyExplosion, transform.position, Quaternion.identity);
            Explosion.Play();


        }
    }
}
