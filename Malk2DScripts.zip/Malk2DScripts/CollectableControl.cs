﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CollectableControl : MonoBehaviour
{
    public PlayerControl player;


    void Start()
    {
        
    }

 
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D ObjCollision)
    {
        if(ObjCollision.CompareTag  ("Player"))
        {
            player.playerScore += 1;
            player.SetUI();
            Destroy(gameObject);
        }
    }
}
