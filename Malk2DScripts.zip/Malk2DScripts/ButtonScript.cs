﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonScript : MonoBehaviour
{
    public bool buttonpressed;
    public GameObject trapObj;
   

    void Start()
    {
        
    }

    
    void Update()
    {
        if (buttonpressed == true)
        {
            
            Destroy(trapObj);

        }
    }
}



//ESTE PARA SUBIR UNA PUERTA
//public class ButtonScript : MonoBehaviour
//{
  //  public bool keyfound;
   // public GameObject wallObj;
   // public Transform pointToMove;
 //  private float movespeed = 10f

  //  void Start()
   // {

   // }


  //  void Update()
   // {
    ///    if (keyfound == true)
     //   {
            //Sube al coger la llave
     //       wallObj.transform.position= Vector3.MoveTowards(wallObj.transform.position,pointtoMove.position,movespeed * Time.deltaTime)

      //  }
   // }
//}