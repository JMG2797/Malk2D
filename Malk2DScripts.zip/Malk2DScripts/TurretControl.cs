﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretControl : MonoBehaviour
{
    public PlayerControl player;
    public enum enemyMood
    {
        Wait, Shoot
    }

    public enemyMood enemyState;

    public GameObject Turret;

    public float TurretLife;

    [Header("Wait")]
    public float timeToWait;
    private float counter;

    [Header("Shoot")]
    public GameObject bullet;
    public Transform target;
    public Transform Socket;
    public float fireRate;
    private float fireCounter;


    void Start()
    {

    }


    void Update()
    {
        if (target != null)
        {
            ChangeState(enemyMood.Shoot);
        }

        switch (enemyState)
        {
            case enemyMood.Wait:
                counter += Time.deltaTime;
                if (counter >= timeToWait)
                {
                    //pasar apatrol
                    ChangeState(enemyMood.Wait);
                    counter = 0;
                }
                break;

        

            case enemyMood.Shoot:

                
                if (target == null)
                {
                    ChangeState(enemyMood.Wait);
                }
                else
                {
                   
                    fireCounter += Time.deltaTime;
                    if (fireCounter > fireRate)
                    {
                        if (bullet != null)
                        {
                            
                            Vector3 bulletDirection = (target.position - transform.position).normalized;

                            
                            GameObject newBullet = Instantiate(bullet, Socket.position, Quaternion.identity);
                            newBullet.GetComponent<EnemyBullet>().targetDir = bulletDirection;
                        }
                        fireCounter = 0;

                    }
                }

                break;
        }

        transform.Rotate(new Vector3(0f, 0f, 1f));
    }

    private void ChangeState(enemyMood newState)
    {
        enemyState = newState;
    }

 
}
