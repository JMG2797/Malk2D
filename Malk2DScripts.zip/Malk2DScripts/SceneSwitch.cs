﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwitch : MonoBehaviour
{
  public void SceneSwitcher0()
    {
        SceneManager.LoadScene(0);
    }

    public void SceneSwitcher1()
    {
        SceneManager.LoadScene(1);
    }

    public void SceneSwitcher2()
    {
        SceneManager.LoadScene(2);
    }

    public void SceneSwitcher3()
    {
        SceneManager.LoadScene(3);
    }

    public void SceneSwitcher4()
    {
        SceneManager.LoadScene(4);
    }

    public void SceneSwitcher5()
    {
        SceneManager.LoadScene(5);
    }

    public void SceneSwitcher6()
    {
        SceneManager.LoadScene(6);
    }

    public void SceneSwitcher7()
    {
        SceneManager.LoadScene(7);
    }
    
    public void SceneSwitcher8()
    {
        SceneManager.LoadScene(8);
    }
}
