﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthScript : MonoBehaviour
{
    public PlayerControl player;

    void Start()
    {
        
    }

    
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D Objcollision)
    {
        if(Objcollision.CompareTag("Player"))
        {
            player.playerLife += 0.15f;
            player.SetUI();
            Destroy(gameObject);
        }
    }
}
