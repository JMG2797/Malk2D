﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyRange : MonoBehaviour
{

    private EnemyControl parentScript;

    void Start()
    {
        //tengo un acceso directo al script de mi parent (el enemy)
        parentScript = transform.parent.GetComponent<EnemyControl>();

    }


    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            //Asigno a mi collider como objetivo de mi parent (enemy)
            parentScript.target = collision.transform;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            //Asigno que mi parent ya no tiene objetivo
            parentScript.target = null;
        }
    }
}
