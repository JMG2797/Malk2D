﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerControl : MonoBehaviour
{
    [Header ("Player Parameters")]
    public float playerSpeed;
    public float jumpForce;
    public float playerLife;
    public float playerStamina;   
    public int playerAmmo;
    public int playerScore;
    public int Lives;


    [Header("Bools")]
    public bool isMoving;
    public bool isGrounded;
    public bool isColliding;
   
    public bool isDashing;
    public bool extraJump;
    public bool isAttacking;

    

    public LayerMask groundlayer;
    public LayerMask wallLayer;

    public Vector3 playerScale;

    [Header("Player Components")]
    private Rigidbody2D PlayerRigidbody;
    public Animator playerAnims;

    [Header("Dash Move")]
    public float DashSpeed;
    private float DashTime;
    public float StartDashTime;
    private int direction;
    public GameObject DashEffect;
    public AudioSource DashSound;

    [Header("Objects")]
    public GameObject playerBullet;
    public Transform pointA;
    public Transform pointB;
    public Transform pointC;
    public Transform pointD;
    public Transform Socket;

    
    public Vector3 LastCheckPoint;

    

    [Header("Player UI")]
    public Text ammoText;
    public Image playerlifeBar;
    public Image playerstaminaBar;
    public Text scoreText;
    public GameObject pauseMenu;

    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody2D>();
        playerScale = transform.localScale;
        playerAnims = GetComponent<Animator>();
        DashTime = StartDashTime;
        DashSound = GetComponent<AudioSource>();

       
        SetUI();
        
    }

    void Update()
    {
        PlayerMovement();
        Shoot();
        GameOver();

        if (Input.GetKeyDown(KeyCode.P))
        {
            pauseMenu.SetActive(true);
            Time.timeScale = 0;
        }

    }
  


    private void PlayerMovement()
    {
        
        isGrounded = Physics2D.OverlapArea(pointC.position, pointD.position, groundlayer);
        isColliding = Physics2D.OverlapArea(pointA.position, pointB.position, wallLayer);
        isDashing = Input.GetKeyDown(KeyCode.E);
        isDashing = Input.GetKeyDown(KeyCode.Q);
        
        
        if (isGrounded == true)
        {
            
            extraJump = true;

            PlayerRigidbody.velocity = new Vector2(Input.GetAxis("Horizontal") *
            playerSpeed, PlayerRigidbody.velocity.y);
        }
        else
        {
            if(isColliding == false)
            {
                PlayerRigidbody.velocity = new Vector2(Input.GetAxis("Horizontal") *
                playerSpeed, PlayerRigidbody.velocity.y);
            }
        }
       
       if(Input.GetAxis("Horizontal") > 0)
        {          
            transform.localScale = playerScale;
        }
        
        if ( Input.GetAxis("Horizontal") < 0)
        {           
            transform.localScale = new Vector3(-playerScale.x, playerScale.y, playerScale.z);
        }

     
        if(Input.GetKeyDown(KeyCode.W))
        {
         
            if (isGrounded == true)
           {
             
                PlayerRigidbody.AddForce(Vector2.up * jumpForce);
            }
            else
            {
               
                if (extraJump == true)
                {
               
                    PlayerRigidbody.AddForce(Vector2.up * jumpForce);
                    extraJump = false;
                }
            }            
        }

        //Dash
        if (isGrounded == false && playerStamina >= 0.1f)
        {
            if (direction == 0)
            {
                if (Input.GetKeyDown(KeyCode.E))
                {
                    
                    direction = 1;
                    playerStamina -= 0.1f;
                    Instantiate(DashEffect, transform.position, Quaternion.identity);
                    DashSound.Play();
                    SetUI();
                    

                }

                else if (Input.GetKeyDown(KeyCode.Q))
                {
                    direction = 2;
                    playerStamina -= 0.1f;
                    Instantiate(DashEffect, transform.position, Quaternion.identity);
                    DashSound.Play();
                    SetUI();
                }
            }

            else
            {
                if (DashTime <= 0)
                {
                    direction = 0;
                    DashTime = StartDashTime;
                    PlayerRigidbody.velocity = Vector2.zero;
                }
                else
                {
                    DashTime -= Time.deltaTime;

                    if (direction == 1)
                    {
                        PlayerRigidbody.velocity = Vector2.right * DashSpeed;
                    }
                    else if (direction == 2)
                    {
                        PlayerRigidbody.velocity = Vector2.left * DashSpeed;
                    }
                }
            }
        }

        //ANIMACIONES PLAYER

        
        if (Input.GetAxis("Horizontal") == 0) 
        {
            playerAnims.SetBool("isMoving", false); 

            //PARA CAMBIAR UN VALOR EN EL ANIMATOR SE PONE NOMBRE DE LA VARIABLE + VALOR DE LA VARIABLE EJ("IsJumping", false)

        }
        else
        {
            playerAnims.SetBool("isMoving", true);
            
        }

        //Animacion Salto
        if(Input.GetKeyDown(KeyCode.W))
        {
            playerAnims.SetBool("isGrounded", false);            
        }
        

        //Animacion Dash
        if(Input.GetKeyDown(KeyCode.Q))
        {
            playerAnims.SetBool("isDashing", true);
        }
        else if(Input.GetKeyDown(KeyCode.E))
        {
            playerAnims.SetBool("isDahing", true);
        }

        //Animacion Attack
        if(Input.GetKeyDown(KeyCode.Space))
        {
            playerAnims.SetBool("isAttacking", true);
        }
        else
        {
            playerAnims.SetBool("isAttacking", false);
        }
    }




    private void Shoot()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
        
            if(playerBullet != null)
            {
              
                if (playerAmmo > 0)
                {
                    
                    GameObject newBullet = Instantiate(
                                    playerBullet,
                                    Socket.position,
                                    Quaternion.identity);
                   

                    if (transform.localScale.x < 0)
                    {
                        newBullet.GetComponent<BulletControl>().bulletSpeed *= -1;
                    }


                   
                    newBullet.GetComponent<BulletControl>().player = this;
                    playerAmmo --;
                    SetUI();
                }
               
            }            
        }
    }

    //Bullet Time
   // public void BulletTime()
    //{
     //   if(Input.GetKeyDown(KeyCode.R))
     //   {
       //     timeManager.DoSlowDown();
      //  }
  //  }

    //Actualiza la info del HUD del jugador
    public void SetUI()
    {
        ammoText.text = "" + playerAmmo;
        scoreText.text = "" + playerScore;
        playerlifeBar.fillAmount = playerLife;
        playerstaminaBar.fillAmount = playerStamina;
        
    }

    private void getDamage(float damage)
    {
        playerLife -= damage;
        if(playerLife <= 0)
        {
            Lives--;
            //Restart level
            Scene Level1;
            Level1 = SceneManager.GetActiveScene();
            SceneManager.LoadScene(Level1.name);
            
        }

        SetUI();
    }

    private void OnTriggerEnter2D (Collider2D ObjCollision)
    {
        if(ObjCollision.CompareTag("EnemyBullet"))
        {
            getDamage(0.25f);
            Destroy(ObjCollision.gameObject);
        }

        else if (ObjCollision.CompareTag("TurretBullet1"))
        {
            getDamage(0.25f);
            Destroy(ObjCollision.gameObject);
        }

        else if (ObjCollision.CompareTag("TurretBullet2"))
        {  
            getDamage(0.5f);
            Destroy(ObjCollision.gameObject);
        }

        else if (ObjCollision.CompareTag("Button"))
        {
            ObjCollision.transform.parent.GetComponent<ButtonScript>().buttonpressed = true;
        }

       
        else if(ObjCollision.CompareTag("LaserWall"))
        {
            getDamage(1f);
            
        }
       
        else if (ObjCollision.CompareTag("Checkpoint"))
        {
            LastCheckPoint = ObjCollision.transform.position;
        }

        
        else if (ObjCollision.CompareTag("Killzone"))
        {
            transform.position = LastCheckPoint;
            Scene Level1;
            Level1 = SceneManager.GetActiveScene();
            SceneManager.LoadScene(Level1.name);     
        }
    }
    public void ResumeGame()
    {
        pauseMenu.SetActive(false);
        Time.timeScale = 1;
    }

  

    public void GameOver()
    {
        if(Lives <= 0)
        {
            SceneManager.LoadScene(4);
        }
    }
}
