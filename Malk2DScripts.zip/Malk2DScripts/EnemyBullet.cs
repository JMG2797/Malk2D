﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{

    public Vector3 targetDir;

    public GameObject ExplosionBullet;
    public float speedBullet;

    public float timeToDestroy;
    private float counter;

    void Start()
    {
        counter = timeToDestroy;
    }


    void Update()
    {
        counter -= Time.deltaTime;
        if (counter < 0)
        {
            Destroy(gameObject);
        }

        transform.Translate(targetDir * speedBullet * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D Objcollision)
    {
        if(Objcollision.CompareTag("Shield"))
        {
            Destroy(gameObject);
        }
    }

}
