﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyControl : MonoBehaviour
{

    [Header("Mood")]
    public enemyMood enemyState;
    public enum enemyMood
    {
        Patrol, Wait, Shoot
    }

    [Header("Patrol")]
    public Transform pointA, pointB;
    public float enemySpeed;
    public bool movingRight;

    [Header("Wait")]
    public float timeToWait;
    private float counter;

    [Header("Shoot")]
    public GameObject bullet;
    public Transform target;
    public float fireRate;
    private float fireCounter;

    [Header("Animator")]
    public Animator EnemyAnims;
    public bool Attack;
    public bool Move;


    void Start()
    {
        EnemyAnims = GetComponent<Animator>();
    }


    void Update()
    {
        if (target != null)
        {
            ChangeState(enemyMood.Shoot);

        }

        switch (enemyState)
        {
            case enemyMood.Wait:
                counter += Time.deltaTime;
                if (counter >= timeToWait)
                {
                    
                    ChangeState(enemyMood.Patrol);
                    counter = 0;
                }
                break;

            case enemyMood.Patrol:
                if (movingRight == true)
                {
                    
                    transform.localScale = Vector3.one;

                    
                    transform.position = Vector3.MoveTowards(
                        transform.position,
                        pointA.position,
                        enemySpeed * Time.deltaTime);
                    
                    if (transform.position == pointA.position)
                    {
                       
                        ChangeState(enemyMood.Wait);
                        movingRight = false;
                    }
                }
                else 
                {
                    transform.localScale = new Vector3(-1, 1, 1);
                    
                    transform.position = Vector3.MoveTowards(
                        transform.position,
                        pointB.position,
                        enemySpeed * Time.deltaTime);
                    
                    if (transform.position == pointB.position)
                    {
                       
                        ChangeState(enemyMood.Wait);
                        movingRight = true;
                    }
                }
                break;

            case enemyMood.Shoot:

                
                if (target == null)
                {
                    ChangeState(enemyMood.Patrol);
                    EnemyAnims.SetBool("Move", true);
                }
                else
                {
                   
                    fireCounter += Time.deltaTime;
                    if (fireCounter > fireRate)
                    {
                        if (bullet != null)
                        {
                           
                            Vector3 bulletDirection = (target.position - transform.position).normalized;

                            
                            GameObject newBullet = Instantiate(bullet, transform.position, Quaternion.identity);
                            newBullet.GetComponent<EnemyBullet>().targetDir = bulletDirection;
                        }
                        fireCounter = 0;

                    }
                }

                break;
        }

    }
    private void ChangeState(enemyMood newState)
    {
        enemyState = newState;
    }

}
