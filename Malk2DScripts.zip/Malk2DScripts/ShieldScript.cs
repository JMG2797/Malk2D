﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldScript : MonoBehaviour
{
    public GameObject Shield;

  

    public PlayerControl player;

    private bool activeshield;



    void Start()
    {
        activeshield = false;
        Shield.SetActive(false);
    }

    
    void Update()
    {
        if ( Input.GetKeyDown(KeyCode.S) && player.playerStamina >= 0.25f && player.isGrounded == true)
        {
            if(!activeshield)
            {
                Shield.SetActive(true);
                activeshield = true;
                Instantiate(Shield, player.transform.position, Quaternion.identity);
                player.playerStamina -= 0.25f;
                player.SetUI();
                
               

            }
            else
            {
                Shield.SetActive(false);
                activeshield = false;
            }
        }
    }

    public bool ActiveShield
    {
        get
        {
            return activeshield;
        }
        set
        {
            activeshield = value;
        }
    }

    private void OnTriggerEnter2D(Collider2D Objcollision)
    {
        if(Objcollision.CompareTag("EnemyBullet"))
        {
            Destroy(Objcollision.gameObject);
            print("Ha impactado contra el escudo");
        }

        else if(Objcollision.CompareTag("TurretBullet1"))
        {
            Destroy(Objcollision.gameObject);
            print ("Ha impactado contra el escudo");
        }
    }

   
}
